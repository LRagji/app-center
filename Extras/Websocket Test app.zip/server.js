const express = require('express');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server, {
    path: '/socket'
});
const port = 3000

app.use('/', express.static('static'))

io.on('connection', function (socket) {
    console.log('a user connected');
    socket.on('disconnect', function () {
        console.log('user disconnected');
    });
    socket.on('chat message', function (msg) {
        console.log("Got message Starting loop:" + msg)
        setInterval(() => { socket.emit('chat message', Date.now()); }, 3000);

    });
});

server.listen(port, () => console.log(`Example app listening on port ${port}!`));

//app.listen(port, () => console.log(`Example app listening on port ${port}!`))